<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>Hello, world!</h1>
<form action="<?php echo e(url('/name')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <!-- Optional JavaScript -->
 
    <input type="hidden" id="demo" oninput="myTestFunction()"  name="token">
    <input type="submit" class="hidden" id="submitButton"   />
</form>

    
<?php




$token="eyJhbGciOiJSUzI1NiIsImtpZCI6Ijg0NjJhNzFkYTRmNmQ2MTFmYzBmZWNmMGZjNGJhOWMzN2Q2NWU2Y2QiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2MTU1MzczMzksImF1ZCI6IjQzNzkyNTI5MzkwMS11azdtOXZyYzA5Zzh0anFxOWVoNW8yaTBmY3B0M2xiYS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwODA2OTAzNjI2ODU1Mzk5MTg4MSIsImVtYWlsIjoiaHVtYW5zaHVkOTUwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiI0Mzc5MjUyOTM5MDEtdWs3bTl2cmMwOWc4dGpxcTllaDVvMmkwZmNwdDNsYmEuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiSGltYW5zaHUgRGhpbWFuIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdqNFFiaTg5TERTaGVtS0lWLXZ6eWhraVJ0T0RVMEIxUEc0bDFRQVZnPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkhpbWFuc2h1IiwiZmFtaWx5X25hbWUiOiJEaGltYW4iLCJpYXQiOjE2MTU1Mzc2MzksImV4cCI6MTYxNTU0MTIzOSwianRpIjoiNTkxM2RlMDgyNjk5YWE1YTZmNWMyZDJhNmFkM2YwMDYwZWQ4NmU2OSJ9.c41_8Qz48YoYdoBFo9sz-0bPLcin_Asp1082WddPHZSweoFj-SogniTUzflvJKCwg9bT-msLvvy-gsoUv_Rmy2--yYqV9kiLmkKyvYQm9QhSohBFy24uz-LlAKvr-XLkcqX2_w__GvpcuPdITJUIQ0v2PepMoVOgYttbdE9e8NKykjUUU7WgHv0qez-4X4VVVTnOA9aoTVVdYVqDh-tSiUUPbDpodbDeF_ICT3BvswSOb_qym9lYVeMbYAbVpwdrdmKTLkL4nQ4OhXEfC17_ozMpoNYmnTDQC_BEer1m5U8ZIfkQbAZ2U_PIY1nKHlJ2_BCtNviWaPIxaTU9IWlNjQ";
  //  $token=cred;


   
$splitName = explode('.', $token,3);


 echo base64_decode($splitName[1]);

?>



    <script src="https://accounts.google.com/gsi/client" async defer></script>

    <script>
    
const myTestFunction=()=>{
  // alert('hi from submit');
  $("#submitButton").trigger("click")  ;
}
   

    const handleCredentialResponse = (res) => {
      const cred = res.credential;
      console.log(cred);
      document.getElementById("demo").value = cred;

document.write(cred);
      window.location='login/' +getvalue;
      myTestFunction()

    }
  window.onload = function () {
    google.accounts.id.initialize({
      client_id: '437925293901-uk7m9vrc09g8tjqq9eh5o2i0fcpt3lba.apps.googleusercontent.com',
      callback: handleCredentialResponse
    });
    
    google.accounts.id.prompt((notification) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
            // try next provider if OneTap is not displayed or skipped
        }
    });
  }
</script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

<?php /**PATH C:\onetaplogin\resources\views/login.blade.php ENDPATH**/ ?>
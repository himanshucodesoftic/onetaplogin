<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<table border="1">
<?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\onetaplogin\resources\views/new.blade.php ENDPATH**/ ?>
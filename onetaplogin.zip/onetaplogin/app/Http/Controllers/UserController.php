<?php

namespace App\Http\Controllers;
use phpseclib\Crypt\RSA as Crypt_RSA;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Http\Request;
use Illuminate\Contracts\Encryption\DecryptException;
use \Firebase\JWT\JWT;
use JWTAuth;

use Tymon\JWTAuth\Exceptions\JWTException;

use phpseclib\File\X509;
class UserController extends Controller
{
    public function index(Request $request)
    {

       
return view('login');
    }
    
    public function encrypt()
    {
$filename=res;
         $encrypted = Crypt::encryptString($filename);
         print_r($encrypted);
    }
    public function decrypt()
    {
         $decrypt= Crypt::decryptString('your_encrypted_string_here');
         print_r($decrypt);
    }
    public function jwt(Request $request)
    {
        try {
            $encryptedValue="eyJhbGciOiJSUzI1NiIsImtpZCI6ImZlZDgwZmVjNTZkYjk5MjMzZDRiNGY2MGZiYWZkYmFlYjkxODZjNzMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2MTQ3NTgwNjMsImF1ZCI6IjQzNzkyNTI5MzkwMS11azdtOXZyYzA5Zzh0anFxOWVoNW8yaTBmY3B0M2xiYS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwODA2OTAzNjI2ODU1Mzk5MTg4MSIsImVtYWlsIjoiaHVtYW5zaHVkOTUwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiI0Mzc5MjUyOTM5MDEtdWs3bTl2cmMwOWc4dGpxcTllaDVvMmkwZmNwdDNsYmEuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiSGltYW5zaHUgRGhpbWFuIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdqNFFiaTg5TERTaGVtS0lWLXZ6eWhraVJ0T0RVMEIxUEc0bDFRQVZnPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkhpbWFuc2h1IiwiZmFtaWx5X25hbWUiOiJEaGltYW4iLCJpYXQiOjE2MTQ3NTgzNjMsImV4cCI6MTYxNDc2MTk2MywianRpIjoiZmExNTZjOTI2ZjczNTgxZDQ0YjkwZDczNTA4NjFiMzlkNjJmNzc4YyJ9.GYczLBX0jNsQA86Knv54j5-tO3o6ijL8h5NlC6fzXOwufBJiD4xHWgGFy7nwuk0TuCXgE04coctm8a8SUrr91nqBCJ81OtA-2Dhp63sG5Un-bFTc3Cmjm9EV6vD3MCykt6eBDg2tDeyp29Ap3oJKJWqqEcQ0JxkH4gCU9TDhJN6SyRw44dWD_oRjazp6sP0svLcp1AN9HOytnS2pgbmhtWezEQiHxCDMAKc8nTSnLJ65ctJMgRR3QdhHKeSz4HWowjLfdhuUzoNcFVe2fTuORDfEQ-7tLCrCOgc1Td7V-5cBRRw09wdFaj4tLwUOxPiEd0Fm9edysMUYWwH2HoXcGw";
            $decrypted = decrypt($encryptedValue);
         } catch (DecryptException $e) {
            //
         } }
}

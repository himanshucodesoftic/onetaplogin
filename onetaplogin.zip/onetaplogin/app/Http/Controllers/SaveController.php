<?php

namespace App\Http\Controllers;
use App\Utils\GeneralUtils;
use App\Models\save;
use App\Models\register;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
class SaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       
       
        $body = $request->all();
        $res=new save();
      
        $token = $request['token'];

        
  $new= $token;

   
   $splitName = explode('.', $new,3);


   $new= base64_decode($splitName[1]);
     


   $person = json_decode($new,true);

    
    $email=$person['email'];

    if(register::where('email', $email )->exists())
    {
    $sel_query = "SELECT * FROM registers where email = '" .$email. "'";
    $res_query = DBraw::select($sel_query);
    $res_query = json_decode(json_encode($res_query), true);
    if (count($res_query)) {
    $res = $res_query[0];
    $token = GeneralUtils::gen_adm_LoginToken();
 
if (GeneralUtils::update_adm_Token($token, $res['id'])) {
    $request->session()->put('ssiapp_adm', true);
    $request->session()->put('ssiapp_id', $res['id']);
     $request->session()->put('ssiapp_email', $res['email']);
    $request->session()->put('ssiapp_name', $res['name']);
    $request->session()->put('ssiapp_token', $token);
 
    return \redirect('newpage');}   
}


}
else
{
    $name = $person['name'] ;
    $email=$person['email'];
    $picture=$person['picture'];
    $given_name=$person['given_name'];
    $family_name=$person['family_name'];
    
    DB::beginTransaction();
    DB::table('registers')->insert([
        // DB::table('events')->insert([
    
        'name' => $name,
        'email' => $email,
        'picture' => $picture,
        'given_name' => $given_name,
        'family_name' => $family_name,
        
    ]);
    
    $id = DB::getPdo()->lastInsertId();
    DB::commit();
    

    // $sel_query = "SELECT * FROM registers where email = '" .$email. "'";
$sel_query = "SELECT * FROM registers where email = '" .$email. "'";
// dd($sel_query);
$res_query = DBraw::select($sel_query);
// dd($res_query);
$res_query = json_decode(json_encode($res_query), true);
// dd($res_query);
if (count($res_query)) {
    $res = $res_query[0];
    $token = GeneralUtils::gen_adm_LoginToken();
 
if (GeneralUtils::update_adm_Token($token, $res['id'])) {
    $request->session()->put('ssiapp_adm', true);
    $request->session()->put('ssiapp_id', $res['id']);
     $request->session()->put('ssiapp_email', $res['email']);
    $request->session()->put('ssiapp_name', $res['name']);
    $request->session()->put('ssiapp_token', $token);
 
    return \redirect('newpage');}   
}

    
    // echo"not found";
}



        return view('login',compact('person'));
    
    }
    // }
    

    public function adminlogout(Request $request)
    {
    
       if ($request->session()->has('ssiapp_adm')) {
          $request->session()->forget(['ssiapp_adm', 'ssiapp_id', 'ssiapp_token']);
        }
        // dd($request->session()->forget(['ssiapp_adm', 'ssiapp_id', 'ssiapp_token'])); 
        return \redirect('/login');
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\save  $save
     * @return \Illuminate\Http\Response
     */
    public function show(save $save,$id)
    {
   
        // return view('new')->with('show',save::find($id));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\save  $save
     * @return \Illuminate\Http\Response
     */
    public function edit(save $save)
    {
        //
    }

    public function tokenstore(Request $request){
        print_r($request->all());
        die;
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\save  $save
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, save $save)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\save  $save
     * @return \Illuminate\Http\Response
     */
    public function destroy(save $save)
    {
        //
    }

    public function adminlogin(Request $request)
    {


       


}


public function newpage(Request $request)
{
    if (!$request->session()->has('ssiapp_id')) {
        return \redirect('/login')->withErrors(['error_reason'=>'Session Don\'t exist']);
    } 
    return view('newpage');
}
}

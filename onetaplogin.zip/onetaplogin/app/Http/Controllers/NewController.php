<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NewController extends Controller
{
// public function new(request $request)
// {


  


//     $token="eyJhbGciOiJSUzI1NiIsImtpZCI6Ijg0NjJhNzFkYTRmNmQ2MTFmYzBmZWNmMGZjNGJhOWMzN2Q2NWU2Y2QiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2MTU1MzczMzksImF1ZCI6IjQzNzkyNTI5MzkwMS11azdtOXZyYzA5Zzh0anFxOWVoNW8yaTBmY3B0M2xiYS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwODA2OTAzNjI2ODU1Mzk5MTg4MSIsImVtYWlsIjoiaHVtYW5zaHVkOTUwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiI0Mzc5MjUyOTM5MDEtdWs3bTl2cmMwOWc4dGpxcTllaDVvMmkwZmNwdDNsYmEuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiSGltYW5zaHUgRGhpbWFuIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdqNFFiaTg5TERTaGVtS0lWLXZ6eWhraVJ0T0RVMEIxUEc0bDFRQVZnPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkhpbWFuc2h1IiwiZmFtaWx5X25hbWUiOiJEaGltYW4iLCJpYXQiOjE2MTU1Mzc2MzksImV4cCI6MTYxNTU0MTIzOSwianRpIjoiNTkxM2RlMDgyNjk5YWE1YTZmNWMyZDJhNmFkM2YwMDYwZWQ4NmU2OSJ9.c41_8Qz48YoYdoBFo9sz-0bPLcin_Asp1082WddPHZSweoFj-SogniTUzflvJKCwg9bT-msLvvy-gsoUv_Rmy2--yYqV9kiLmkKyvYQm9QhSohBFy24uz-LlAKvr-XLkcqX2_w__GvpcuPdITJUIQ0v2PepMoVOgYttbdE9e8NKykjUUU7WgHv0qez-4X4VVVTnOA9aoTVVdYVqDh-tSiUUPbDpodbDeF_ICT3BvswSOb_qym9lYVeMbYAbVpwdrdmKTLkL4nQ4OhXEfC17_ozMpoNYmnTDQC_BEer1m5U8ZIfkQbAZ2U_PIY1nKHlJ2_BCtNviWaPIxaTU9IWlNjQ";
       
//     $splitName = explode('.', $token,3);
    
    
//      echo base64_decode($splitName[1]);
// }

public function new($getvalue)
{
    echo $getvalue;
}




}

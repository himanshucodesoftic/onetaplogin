<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\save;
use Illuminate\Support\Facades\Crypt;
class encryptdata extends Controller
{
    public function encrypt(Request $request)
    {
        $request->save()->fill([
            'token' => Crypt::encryptString($request->token),
        ])->save();
    }

    public function decrypt(Request $request)
    {
        try {
            $decrypted = Crypt::decryptString($encryptedValue);
        } catch (DecryptException $e) {
            //
        }

    }
}

<a class="dropdown-item" href="{{ url('/admin/logout') }}"><i class="fa fa-sign-out fa-lg"></i>
    Logout</a></li>
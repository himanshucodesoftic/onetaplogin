<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/login', function () {
    return view('login');
});

Route::get('/successfull', function () {
    return view('successfull');
});


// Route::get('login',"App\Http\Controllers\UserController@index");

// Route::get('encrypt',"App\Http\Controllers\UserController@encrypt");

Route::get('welcome/addupdate/{id}', "App\Http\Controllers\UserController@addUpdateData");

Route::get('/newpage',"App\Http\Controllers\SaveController@newpage");
Route::get('/admin/logout','App\Http\Controllers\SaveController@adminlogout');
Route::post('/name',"App\Http\Controllers\SaveController@store");
Route::post('/token/post',"App\Http\Controllers\SaveController@tokenstore")->name('token.post');

// Route::get('/new',"App\Http\Controllers\Encryptdata@encrypt");


Route::get('/news',"App\Http\Controllers\Encryptdata@decrypt");


Route::get('/new',"App\Http\Controllers\News@new");


Route::get('/index/{getvalue}',"App\Http\Controllers\NewController@new");